﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzariaDoZe.UserControls
{
    /// <summary>
    /// User control da barra lateral
    /// </summary>
    public partial class ConfiguracoesUserControlForm : UserControl
    {
        /// <summary>
        /// User control da barra lateral
        /// </summary>
        public ConfiguracoesUserControlForm()
        {
            InitializeComponent();
        }
    }
}
