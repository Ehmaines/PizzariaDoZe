﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzariaDoZe.UserControls
{
    /// <summary>
    /// User control do botão de cadastrar usuario
    /// </summary>
    public partial class CadastrarFuncionarioUserControlForm : UserControl
    {
        /// <summary>
        /// User control do botão de cadastrar usuario
        /// </summary>
        public CadastrarFuncionarioUserControlForm()
        {
            InitializeComponent();
        }
    }
}
