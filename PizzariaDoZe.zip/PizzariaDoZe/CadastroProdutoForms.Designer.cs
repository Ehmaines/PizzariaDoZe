﻿namespace PizzariaDoZe
{
    partial class CadastroProdutoForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            saveCloseUserControlForm1 = new SaveCloseUserControlForm();
            labelId = new Label();
            txtIngredienteId = new TextBox();
            labelNome = new Label();
            txtNomeIngrediente = new TextBox();
            labelCadastrarProduto = new Label();
            labelValor = new Label();
            textBoxValor = new TextBox();
            listBox1 = new ListBox();
            labelTipo = new Label();
            labelMl = new Label();
            listBox2 = new ListBox();
            SuspendLayout();
            // 
            // saveCloseUserControlForm1
            // 
            saveCloseUserControlForm1.BackColor = Color.FromArgb(39, 39, 41);
            saveCloseUserControlForm1.Location = new Point(254, 582);
            saveCloseUserControlForm1.Margin = new Padding(4, 6, 4, 6);
            saveCloseUserControlForm1.Name = "saveCloseUserControlForm1";
            saveCloseUserControlForm1.Size = new Size(329, 60);
            saveCloseUserControlForm1.TabIndex = 40;
            // 
            // labelId
            // 
            labelId.AutoSize = true;
            labelId.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelId.ForeColor = Color.GhostWhite;
            labelId.Location = new Point(62, 89);
            labelId.Margin = new Padding(2, 0, 2, 0);
            labelId.Name = "labelId";
            labelId.Size = new Size(91, 32);
            labelId.TabIndex = 39;
            labelId.Text = "Código";
            // 
            // txtIngredienteId
            // 
            txtIngredienteId.BackColor = Color.GhostWhite;
            txtIngredienteId.Enabled = false;
            txtIngredienteId.Location = new Point(59, 128);
            txtIngredienteId.Margin = new Padding(4);
            txtIngredienteId.Name = "txtIngredienteId";
            txtIngredienteId.Size = new Size(112, 31);
            txtIngredienteId.TabIndex = 36;
            // 
            // labelNome
            // 
            labelNome.AutoSize = true;
            labelNome.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelNome.ForeColor = Color.GhostWhite;
            labelNome.Location = new Point(62, 179);
            labelNome.Margin = new Padding(2, 0, 2, 0);
            labelNome.Name = "labelNome";
            labelNome.Size = new Size(80, 32);
            labelNome.TabIndex = 38;
            labelNome.Text = "Nome";
            // 
            // txtNomeIngrediente
            // 
            txtNomeIngrediente.BackColor = Color.GhostWhite;
            txtNomeIngrediente.Location = new Point(59, 214);
            txtNomeIngrediente.Margin = new Padding(4);
            txtNomeIngrediente.Name = "txtNomeIngrediente";
            txtNomeIngrediente.Size = new Size(509, 31);
            txtNomeIngrediente.TabIndex = 35;
            // 
            // labelCadastrarProduto
            // 
            labelCadastrarProduto.AutoSize = true;
            labelCadastrarProduto.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            labelCadastrarProduto.ForeColor = Color.GhostWhite;
            labelCadastrarProduto.Location = new Point(59, 11);
            labelCadastrarProduto.Margin = new Padding(2, 0, 2, 0);
            labelCadastrarProduto.Name = "labelCadastrarProduto";
            labelCadastrarProduto.Size = new Size(485, 65);
            labelCadastrarProduto.TabIndex = 37;
            labelCadastrarProduto.Text = "Cadastro de Produtos";
            // 
            // labelValor
            // 
            labelValor.AutoSize = true;
            labelValor.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelValor.ForeColor = Color.GhostWhite;
            labelValor.Location = new Point(62, 271);
            labelValor.Margin = new Padding(2, 0, 2, 0);
            labelValor.Name = "labelValor";
            labelValor.Size = new Size(67, 32);
            labelValor.TabIndex = 42;
            labelValor.Text = "Valor";
            // 
            // textBoxValor
            // 
            textBoxValor.BackColor = Color.GhostWhite;
            textBoxValor.Location = new Point(59, 306);
            textBoxValor.Margin = new Padding(4);
            textBoxValor.Name = "textBoxValor";
            textBoxValor.Size = new Size(509, 31);
            textBoxValor.TabIndex = 41;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Items.AddRange(new object[] { "Refrigerante", "Cerveja", "Água", "Suco" });
            listBox1.Location = new Point(62, 399);
            listBox1.Margin = new Padding(4);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(176, 154);
            listBox1.TabIndex = 43;
            // 
            // labelTipo
            // 
            labelTipo.AutoSize = true;
            labelTipo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelTipo.ForeColor = Color.GhostWhite;
            labelTipo.Location = new Point(62, 360);
            labelTipo.Margin = new Padding(2, 0, 2, 0);
            labelTipo.Name = "labelTipo";
            labelTipo.Size = new Size(61, 32);
            labelTipo.TabIndex = 44;
            labelTipo.Text = "Tipo";
            // 
            // labelMl
            // 
            labelMl.AutoSize = true;
            labelMl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelMl.ForeColor = Color.GhostWhite;
            labelMl.Location = new Point(279, 360);
            labelMl.Margin = new Padding(2, 0, 2, 0);
            labelMl.Name = "labelMl";
            labelMl.Size = new Size(47, 32);
            labelMl.TabIndex = 46;
            labelMl.Text = "ML";
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 25;
            listBox2.Items.AddRange(new object[] { "150", "300", "600", "1000", "1500", "2000" });
            listBox2.Location = new Point(279, 399);
            listBox2.Margin = new Padding(4);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(176, 154);
            listBox2.TabIndex = 45;
            // 
            // CadastroProdutoForms
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(39, 39, 41);
            ClientSize = new Size(606, 664);
            Controls.Add(labelMl);
            Controls.Add(listBox2);
            Controls.Add(labelTipo);
            Controls.Add(listBox1);
            Controls.Add(labelValor);
            Controls.Add(textBoxValor);
            Controls.Add(saveCloseUserControlForm1);
            Controls.Add(labelId);
            Controls.Add(txtIngredienteId);
            Controls.Add(labelNome);
            Controls.Add(txtNomeIngrediente);
            Controls.Add(labelCadastrarProduto);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(4);
            Name = "CadastroProdutoForms";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastroProdutoForms";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private SaveCloseUserControlForm saveCloseUserControlForm1;
        private Label labelId;
        private TextBox txtIngredienteId;
        private Label labelNome;
        private TextBox txtNomeIngrediente;
        private Label labelCadastrarProduto;
        private Label labelValor;
        private TextBox textBoxValor;
        private ListBox listBox1;
        private Label labelTipo;
        private Label labelMl;
        private ListBox listBox2;
    }
}